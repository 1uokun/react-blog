TypeScript is authored by:
* Aaron Holmes
* Abubaker Bashir
* Adam Freidin
* Adi Dahiya
* Aditya Daflapurkar
* Adnan Chowdhury 
* Adrian Leonhard 
* Adrien Gibrat 
* Ahmad Farid
* Akshar Patel
* Alan Agius 
* Alex Chugaev 
* Alex Eagle
* Alex Khomchenko 
* Alex Ryan 
* Alexander Kuvaev
* Alexander Rusakov 
* Alexander Tarasyuk
* Ali Sabzevari
* Aliaksandr Radzivanovich
* Aluan Haddad 
* Anatoly Ressin 
* Anders Hejlsberg
* Andreas Martin
* Andrej Baran 
* Andrew Casey 
* Andrew Faulkner 
* Andrew Ochsner 
* Andrew Stegmaier 
* Andrew Z Allen
* András Parditka 
* Andy Hanson
* Anil Anar
* Anton Khlynovskiy 
* Anton Tolmachev
* Anubha Mathur 
* Armando Aguirre 
* Arnaud Tournier 
* Arnav Singh
* Artem Tyurin 
* Arthur Ozga
* Asad Saeeduddin
* Avery Morin
* Basarat Ali Syed
* @begincalendar
* Ben Duffield
* Ben Mosher 
* Benjamin Bock 
* Benjamin Lichtman 
* Benny Neugebauer 
* Bill Ticehurst
* Blaine Bublitz 
* Blake Embrey
* @bluelovers
* @bootstraponline
* Bowden Kelly
* Bowden Kenny
* Brandon Slade 
* Brett Mayen
* Bryan Forbes
* Caitlin Potter
* Cameron Taggart 
* @cedvdb
* Charles Pierce 
* Charly POLY 
* Chris Bubernak
* Christophe Vidal 
* Chuck Jazdzewski
* Colby Russell
* Colin Snover
* Cotton Hou 
* Cyrus Najmabadi
* Dafrok Zhang
* Dahan Gong
* Dan Corder
* Dan Freeman 
* Dan Quirk
* Daniel Gooss
* Daniel Hollocher
* Daniel Król 
* Daniel Lehenbauer
* Daniel Rosenwasser
* David Kmenta
* David Li
* David Sheldrick 
* David Sherret 
* David Souther
* David Staheli 
* Denis Nedelyaev
* Derek P Sifford 
* Dhruv Rajvanshi 
* Dick van den Brink
* Diogo Franco (Kovensky) 
* Dirk Bäumer
* Dirk Holtwick
* Dom Chen 
* Donald Pipowitch 
* Doug Ilijev
* @e-cloud
* Ecole Keine
* Elisée Maurer
* Elizabeth Dinella 
* Emilio García-Pumarino
* Eric Grube 
* Eric Tsang
* Erik Edrosa
* Erik McClenney 
* Esakki Raj 
* Ethan Resnick 
* Ethan Rubio
* Eugene Timokhov 
* Evan Martin
* Evan Sebastian
* Eyas Sharaiha
* Fabian Cook 
* @falsandtru
* Filipe Silva 
* @flowmemo
* Francois Wouts 
* Frank Wallis
* Franklin Tse
* František Žiacik
* Gabe Moothart 
* Gabriel Isenberg
* Gilad Peleg
* Godfrey Chan 
* Graeme Wicksted
* Guilherme Oenning
* Guillaume Salles
* Guy Bedford
* Halasi Tamás 
* Harald Niesche
* Hendrik Liebau 
* Henry Mercer 
* Herrington Darkholme
* Holger Jeromin 
* Homa Wong 
* Iain Monro
* @IdeaHunter
* Igor Novozhilov
* Ika 
* Ingvar Stepanyan
* Isiah Meadows
* Ivan Enderlin 
* Ivo Gabe de Wolff
* Iwata Hidetaka 
* Jack Williams 
* Jakub Korzeniowski
* Jakub Młokosiewicz 
* James Henry 
* James Whitney
* Jan Melcher 
* Jason Freeman
* Jason Jarrett 
* Jason Killian
* Jason Ramsay
* JBerger
* Jed Mao
* Jeffrey Morlan
* Jesse Schalken
* Jing Ma 
* Jiri Tobisek
* Joe Calzaretta 
* Joe Chung 
* Joel Day 
* Joey Wilson
* Johannes Rieken
* John Doe 
* John Vilk
* Jonathan Bond-Caron
* Jonathan Park
* Jonathan Toland
* Jonathan Turner
* Jonathon Smith
* Jordi Oliveras Rovira 
* Joscha Feth 
* Josh Abernathy 
* Josh Goldberg 
* Josh Kalderimis
* Josh Soref
* Juan Luis Boya García
* Julian Williams
* Justin Bay 
* Justin Johansson 
* K. Preißer
* Kagami Sascha Rosylight
* Kanchalai Tanglertsampan
* Kate Miháliková 
* Keith Mashinter
* Ken Howard
* Kenji Imamula
* Kerem Kat
* Kevin Donnelly 
* Kevin Gibbons 
* Kevin Lang 
* Khải 
* Kitson Kelly 
* Klaus Meinhardt 
* Kris Zyp 
* Kyle Kelley
* Kārlis Gaņģis
* Lorant Pinter
* Lucien Greathouse
* Lukas Elmer 
* Maarten Sijm 
* Magnus Hiie 
* Magnus Kulke 
* Manish Giri
* Marin Marinov
* Marius Schulz 
* Markus Johnsson 
* Martin Hiller 
* Martin Probst 
* Martin Vseticka
* Martyn Janes 
* Masahiro Wakame
* Mateusz Burzyński 
* Matt Bierner 
* Matt McCutchen
* Matt Mitchell 
* Mattias Buelens
* Mattias Buelens 
* Max Deepfield
* Maxwell Paul Brickner 
* @meyer
* Micah Zoltu
* @micbou
* Michael 
* Michael Bromley
* Mike Busyrev 
* Mike Morearty 
* Mine Starks 
* Mohamed Hegazy
* Mohsen Azimi 
* Myles Megyesi 
* Nathan Shively-Sanders
* Nathan Yee
* Nicolas Henry
* Nicu Micleușanu
* @nieltg
* Nima Zahedi
* Noah Chen 
* Noel Varanda 
* Noj Vek
* Oleg Mihailik
* Oleksandr Chekhovskyi
* Omer Sheikh 
* Orta Therox
* Oskar Segersva¨rd
* Oussama Ben Brahim 
* Patrick Zhong
* Paul Jolly
* Paul Koerbitz 
* Paul van Brenk
* @pcbro
* Pedro Maltez
* Perry Jiang
* Peter Burns
* Philip Bulley
* Philippe Voinov 
* Pi Lanningham 
* Piero Cangianiello
* @piloopin
* Prayag Verma
* Priyantha Lankapura 
* @progre
* Punya Biswal
* Rado Kirov
* Raj Dosanjh
* Reiner Dolp 
* Remo H. Jansen 
* @rhysd
* Ricardo N Feliciano 
* Richard Karmazín 
* Richard Knoll
* Richard Sentino
* Robert Coie
* Rohit Verma
* Ron Buckton
* Rostislav Galimsky 
* Rowan Wyborn
* Ryan Cavanaugh
* Ryohei Ikegami
* Sam Bostock 
* Sam El-Husseini 
* Sarangan Rajamanickam
* Sean Barag 
* Sergey Rubanov
* Sergey Shandar 
* Sergii Bezliudnyi 
* Sharon Rolel 
* Sheetal Nandi
* Shengping Zhong
* Shyyko Serhiy
* Simon Hürlimann
* Slawomir Sadziak 
* Solal Pirelli
* Soo Jae Hwang 
* Stan Thomas
* Stanislav Iliev 
* Stanislav Sysoev
* Stas Vilchik 
* Stephan Ginthör 
* Steve Lucco
* @styfle
* Sudheesh Singanamalla 
* Sébastien Arod
* @T18970237136
* @t_
* Taras Mankovski 
* Tarik Ozket
* Tetsuharu Ohzeki
* Thomas den Hollander 
* Thomas Loubiou
* Tien Hoanhtien
* Tim Lancina 
* Tim Perry
* Tim Viiding-Spader
* Tingan Ho
* Todd Thomson
* togru
* Tomas Grubliauskas
* Torben Fitschen 
* @TravCav
* TruongSinh Tran-Nguyen
* Tycho Grouwstra 
* Vadi Taslim 
* Vakhurin Sergey 
* Vidar Tonaas Fauske
* Viktor Zozulyak
* Vilic Vane
* Vimal Raghubir 
* Vladimir Kurchatkin 
* Vladimir Matveev
* Vyacheslav Pukhanov 
* Wenlu Wang 
* Wesley Wigham
* William Orr 
* Wilson Hobbs 
* York Yao
* @yortus
* Yuichi Nukiyama
* Yuval Greenfield 
* Zeeshan Ahmed 
* Zev Spitz
* Zhengbo Li
* @Zzzen